const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ⚠️ Change this before deploying — only people who know this PIN can view
// passenger entries. Keep it the same as ADMIN_PIN in driver.html / admin.html.
const ADMIN_PIN = process.env.ADMIN_PIN || 'ece';

// ---------------------------------------------------------------
// Bus location tracking (used by driver.html and map.html)
// ---------------------------------------------------------------
let buses = {}; // busId -> { lat, lng, routeNo, driverName, updatedAt }

app.post('/update/:busId', (req, res) => {
  const { busId } = req.params;
  const { lat, lng, routeNo, driverName } = req.body;

  if (typeof lat !== 'number' || typeof lng !== 'number') {
    return res.status(400).json({ error: 'lat and lng must be numbers' });
  }

  buses[busId] = {
    lat,
    lng,
    routeNo: routeNo || '',
    driverName: driverName || '',
    updatedAt: Date.now()
  };

  res.json({ ok: true });
});

app.get('/buses', (req, res) => {
  res.json(buses);
});

// ---------------------------------------------------------------
// Passenger entries — passenger submits their name + chosen bus.
// Stored in memory and only visible to whoever has the admin PIN.
// ---------------------------------------------------------------
let passengerEntries = []; // { id, name, busId, busLabel, timestamp }
let nextEntryId = 1;

app.post('/passenger-entry', (req, res) => {
  const { name, busId, busLabel } = req.body;

  if (!name || !String(name).trim() || !busId) {
    return res.status(400).json({ error: 'name and busId are required' });
  }

  const entry = {
    id: nextEntryId++,
    name: String(name).trim(),
    busId: String(busId).trim(),
    busLabel: busLabel ? String(busLabel).trim() : String(busId).trim(),
    timestamp: Date.now()
  };

  passengerEntries.push(entry);

  // Cap memory usage — keep only the most recent 1000 entries
  if (passengerEntries.length > 1000) {
    passengerEntries = passengerEntries.slice(-1000);
  }

  res.json({ ok: true, entry });
});

// Admin-only: view all passenger entries. Requires ?pin=ADMIN_PIN
app.get('/passenger-entries', (req, res) => {
  if (req.query.pin !== ADMIN_PIN) {
    return res.status(403).json({ error: 'Invalid admin PIN' });
  }
  // Newest first
  res.json([...passengerEntries].reverse());
});

// Admin-only: clear all passenger entries. Requires ?pin=ADMIN_PIN
app.delete('/passenger-entries', (req, res) => {
  if (req.query.pin !== ADMIN_PIN) {
    return res.status(403).json({ error: 'Invalid admin PIN' });
  }
  passengerEntries = [];
  res.json({ ok: true });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`System to Track Vehicle backend running on port ${PORT}`);
});
